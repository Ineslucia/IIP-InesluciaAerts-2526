using System;
using System.Collections.Generic;

class Program
{
 //methode BlokNaarUren
 public string BlokNaarUren()
 {
   Console.Write("Geef aantal auto's voor blok 1 (uur 0-6u): ");
   Console.Write("Geef aantal auto's voor blok 2 (uur 6-12u): ");
   Console.Write("Geef aantal auto's voor blok 3 (uur 12-18u): ");
   Console.Write("Geef aantal auto's voor blok 4 (uur 18-24u): ");
   Console.ReadLine();
 }
 
 //metode BerekenTotaal
   public int BerekenTotaal(int[] autosPerBlok)
{
    int totaal = 0;

    for (int i = 0; i < autosPerBlok.Length; i++)
    {
        totaal += autosPerBlok[i];
    }

    return totaal;
	
	Console.Write($"Totaal aantal auto's:{totaal}");
}
 
 
 //methode BepaalDruksteBlok
 public int BepaalDruksteBlok()
{
 
 
 
BlokNaarUren();
}


//methode ZoekRustigeBlokken
public int ZoekRustigeBlokken()
{
  Console.Write("Geef een grens voor rustige blokken: ");
  Console.ReadLine();
 
  Console.WriteLine($"Rustige blokken (minder dan {grens} auto's): {string.Join(", ", getallen)}");
   if ( i > grens)
  {
  Console.Write("Geen rustige blokken");
  }
}
 

static void Main(string[] args)
{
   int autosPerBlok[] = new int[4];
   for (int i = 1; i < autosPerBlok.Length; i++;) 
   BlokNaarUren();
  
   Console.WriteLine($"Auto's per blok: {string.Join(", ", getallen)}");
   BerekenTotaal();
   BlokNaarUren();
   ZoekRustigeBlokken();
   
}